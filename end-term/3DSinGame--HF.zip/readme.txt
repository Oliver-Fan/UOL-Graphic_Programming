comments on work:
Thank you for checking my work. It will be my great honor to show you what I have done.

 I have implemented points 1 to 5, the sturcture is wavy like the demo at the top of the Coursera page.
 A grid of tiles of the right size, spread over the right area, has been produced.
 Material and stroke is on display, camera flies around the structure continuously.
 Cofetti spinning downwards to the ground and when it reaches the bottom, it resets to the top.
 
 For further development, I have implemented two control slider at top so that user can control weight and height of those blocks.
 In this way, a beautiful wave will appear with the slider was dragged.  

And I have set four point lights with different color so that 
it can map the rotating squares with different colors

 Thank you.