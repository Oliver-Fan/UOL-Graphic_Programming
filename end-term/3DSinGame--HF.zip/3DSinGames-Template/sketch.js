/*
comments on work:
Thank you for checking my work.

 I have implemented points 1 to 5, the sturcture is wavy like the demo at the top of the Coursera page and camera flies around the structure continuously. Cofetti spinning downwards to the ground and when it reaches the bottom, it resets to the top.
 
  For further development, I have implemented two control slider at top so that user can control weight and height of those blocks, in this way, a beautiful wave will appear with the slider was dragged. 

  And I have set four point lights with different color so that the it can map the rotating squares with different colors
*/

var weightSlider;
var heightSlider;
var confLocs = []; // to store the location of each confetti

var confTheta = []; //to store the initial angle of each confetti

function setup() {
    createCanvas(1000, 1000, WEBGL);
    camera(800, -600, 800, 0, 0, 0, 0, 1, 0);
    angleMode(DEGREES);

    //step 5
    for (var i = 0; i < 200; i++) {
        //push 200 3D vectors into confLocs
        var confLocs_x = random(-500, 500);
        var confLocs_y = random(-800, 0);
        var confLocs_z = random(-500, 500);
        var confLocs_vector = createVector(confLocs_x, confLocs_y, confLocs_z);
        confLocs.push(confLocs_vector);
        //Push also a random angle from 0 to 360 onto the confTheta array
        var confLocs_angle = random(0, 360);
        confTheta.push(confLocs_angle);
    }

    //Further Dev : create control slider for height and weight, 
    weightSlider = createSlider(0, 255, 100);
    weightSlider.position(100, 10);

    heightSlider = createSlider(0, 300, 0);
    heightSlider.position(100, 40);
}

function draw() {
    background(155);
    angleMode(DEGREES);

    //Further Dev:Set up point lights of different colors to map the rotating squares with different colors
    push();
    ambientLight(60, 60, 60);
    pointLight(130, 100, 189, 400, -200, 100);
    pointLight(130, 0, 189, -400, -200, 100);
    pointLight(50, 150, 195, 300, 100, -800);
    pointLight(200, 0, 25, 200, 100, 800);
    // Step 1
    for (var x = -400; x <= 400; x += 50) {
        for (var z = -400; z <= 400; z += 50) {
            push();
            translate(x, 0, z);

            // Step 3
            var distance = dist(0, 0, x, z);
            var value = weightSlider.value();
            var length = map(sin(distance + value * 5), -1, 1, 100, 300);
            box(50, length + heightSlider.value(), 50);
            pop();
        }

        // Step 2
        normalMaterial();
        stroke(0);
        strokeWeight(10);

        // Step 4
        //Add frameCount to distance in order to animate the wave
        var camX = cos(frameCount) * height;
        var camZ = sin(frameCount) * height;
        camera(camX, -800, camZ, 0, 0, 0, 0, 1, 0);
    }

    //step 5-call confetti() function
    push();
    noStroke();
    confetti();
    pop();
}

function confetti() {
    for (var i = 0; i < confLocs.length; i++) {
        push();
        translate(confLocs[i].x, confLocs[i].y, confLocs[i].z);
        rotateX(confTheta[i]);
        plane(15, 15);

        //Increment the y-coordinate of the specific confetti by 1 
        confLocs[i].y += 1;

        // increment the rotation by 10
        confTheta[i] += 10;

        if (confLocs[i].y > 0) {
            confLocs[i].y = -800;
        }

        pop();
    }
}
