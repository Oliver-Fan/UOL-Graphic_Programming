// ********************************
// BACKGROUND SUBTRACTION EXAMPLE *
// ********************************
var video;
var prevImg;
var diffImg;
var currImg;
var thresholdSlider;
var threshold;
var grid;
var monoSynth;
var checkBox;

function setup() {
    createCanvas(640 * 2, 480);
    pixelDensity(1);
    video = createCapture(VIDEO);
    video.hide();

    thresholdSlider = createSlider(0, 255, 50);
    thresholdSlider.position(20, 20);

    soundCheckbox = createCheckbox('Sound', false);
    soundCheckbox.position(20, 60);

    grid = new Grid(640,480);

    monoSynth = new p5.MonoSynth();
}

function draw() {
    background(0);
    image(video, 0, 0);

    currImg = createImage(video.width, video.height);
    currImg.copy(video, 0, 0, video.width, video.height, 0, 0, video.width, video.height);
    currImg.resize(currImg.width/4, currImg.height/4);
    currImg.filter(BLUR,3);

    diffImg = createImage(video.width, video.height);
    diffImg.resize(diffImg.width/4,diffImg.height/4);
    diffImg.loadPixels();

    threshold = thresholdSlider.value();
    userStartAudio();

    if (typeof prevImg !== 'undefined') {
        prevImg.loadPixels();
        currImg.loadPixels();
        for (var x = 0; x < currImg.width; x += 1) {
            for (var y = 0; y < currImg.height; y += 1) {
                var index = (x + (y * currImg.width)) * 4;
                var redSource = currImg.pixels[index + 0];
                var greenSource = currImg.pixels[index + 1];
                var blueSource = currImg.pixels[index + 2];

                var redBack = prevImg.pixels[index + 0];
                var greenBack = prevImg.pixels[index + 1];
                var blueBack = prevImg.pixels[index + 2];

                var d = dist(redSource, greenSource, blueSource, redBack, greenBack, blueBack);

                if (d > threshold) {
                    diffImg.pixels[index + 0] = 0;
                    diffImg.pixels[index + 1] = 0;
                    diffImg.pixels[index + 2] = 0;
                    diffImg.pixels[index + 3] = 255;

                    toggleSound(x, y);
                } else {
                    diffImg.pixels[index + 0] = 255;
                    diffImg.pixels[index + 1] = 255;
                    diffImg.pixels[index + 2] = 255;
                    diffImg.pixels[index + 3] = 255;
                    monoSynth.triggerRelease();
                }
            }
        }
    }
    diffImg.updatePixels();
    image(diffImg, 640, 0);

    noFill();
    stroke(255);
    text(threshold, 160, 35);

    copyCurrentToPrevImage();

    grid.run(diffImg);
}

function copyCurrentToPrevImage(){
    prevImg = createImage(currImg.width, currImg.height);
    prevImg.copy(currImg, 0, 0, currImg.width, currImg.height, 0, 0, currImg.width, currImg.height);
}

function keyPressed() {
    // prevImg = createImage(currImg.width, currImg.height);
    // prevImg.copy(currImg, 0, 0, currImg.width, currImg.height, 0, 0, currImg.width, currImg.height);
    // console.log("saved new background");
    // monoSynth.triggerAttack("E3");
}

// faster method for calculating color similarity which does not calculate root.
// Only needed if dist() runs slow
function distSquared(x1, y1, z1, x2, y2, z2){
  var d = (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) + (z2-z1)*(z2-z1);
  return d;
}

function playNotes(x, y) {
    // top left corner
    if(x < currImg.width/2 && 
    x > 0 &&
    y < currImg.height/2 &&
    y > 0) {
    monoSynth.triggerAttack("C4", 1, 0.2);
    }
    // top right corner
    if(x < currImg.width &&
        x > currImg.width/2 && 
        y < currImg.height/2 &&
        y > 0) {
    monoSynth.triggerAttack("E4");
    }
    // bottom left corner
    if(x < currImg.width/2 &&
        x > 0 && 
        y < currImg.height &&
        y > currImg.height/2) {
    monoSynth.triggerAttack("G4");
    }
    // bottom right corner
    if(x < currImg.width &&
        x > currImg.width/2 && 
        y < currImg.height &&
        y > currImg.height/2) {
    monoSynth.triggerAttack("C5");
    }
}

function toggleSound(x, y) {
    if(soundCheckbox.checked()) { // if checkbox is checked, play sound
        // console.log("soundCheckbox is true");
        playNotes(x, y);
    }
    else { // if checkbox is not checked, do not play sound
        // console.log("soundCheckbox is false");
    }
}