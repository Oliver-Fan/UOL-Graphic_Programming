var imgs = [];
var avgImg;
var numOfImages = 30;
var imgOut;
var loadCounter = 0;

//////////////////////////////////////////////////////////
function preload() { // preload() runs once
     for(var i =0 ; i<numOfImages ; i++)
     {
         imgs.push(loadImage("assets/" + i + ".jpg", imageloadedSuccess));
     }
}
//////////////////////////////////////////////////////////
function setup() {
    imgOut = imgs[0];
    
    avgImg = createGraphics(imgs[0].width,imgs[0].height);
    
    pixelDensity(1);
    
    createCanvas(imgOut.width*2, imgOut.height);
}
//////////////////////////////////////////////////////////
function draw() {
    background(125);
     image(imgOut,0,0);
    
    // if the number of loaded img not equal to the numOfImages, show the "Not Ready" message
    if(loadCounter != numOfImages)
        {
            console.log("Not Ready");
            return         
        }
    
    //load the pixels of all images in the array
    for(var i =0 ; i<imgs.length ; i++)
        {
            imgs[i].loadPixels();
        }
    avgImg.loadPixels();
    
    //each row
    for(var y =0 ; y<imgOut.height ; y++)
        {
            //each col
            for(var x =0 ; x<imgOut.width ; x++)
                {
                    var pixelIndex = (imgOut.width * y + x)*4;
                    var sumR = 0 ;
                    var sumG = 0 ;
                    var sumB = 0 ;
                    for(var j=0 ; j<imgs.length ; j++)
                        {
                            sumR+=imgs[j].pixels[pixelIndex];
                            sumG+=imgs[j].pixels[pixelIndex+1];
                            sumB+=imgs[j].pixels[pixelIndex+2];
                        }
                    avgImg.pixels[pixelIndex]=sumR/imgs.length;
                    avgImg.pixels[pixelIndex+1]=sumG/imgs.length;
                    avgImg.pixels[pixelIndex+2]=sumB/imgs.length;
                    avgImg.pixels[pixelIndex+3]=255;
                }
        }
    avgImg.updatePixels();
    image(avgImg,imgOut.width,0);
    noLoop();
}

function imageloadedSuccess()
{
    loadCounter++;
    console.log(loadCounter);
    console.log("images loaded successfully");
}

