var slider;
var heightSlider;

function setup() {
    createCanvas(1000, 1000, WEBGL);
    camera(800,-600,800,0,0,0,0,1,0);
    angleMode(DEGREES);

    confLocs = [];
    confTheta = [];

    for(var i=0; i<200; i++) {
        var r_x = random(-500,500);
        var r_y = random(-800,0);
        var r_z = random(-500,500);
        var r_v = createVector(r_x,r_y,r_z);
        confLocs.push(r_v);
        var r_a = random(0,360);
        confTheta.push(r_a);
    }

    slider = createSlider(0, 255, 100);
    slider.position(10, 10);

    heightSlider = createSlider(0, 300, 0);
    heightSlider.position(10, 40);
}

function draw() {
    background(130);
    angleMode(DEGREES);
    
    // Step 4
    var xLoc = cos(frameCount)*height;
    var zLoc = sin(frameCount)*height;
    camera(xLoc,-600,zLoc,0,0,0,0,1,0);

    // Step 2
    // normalMaterial();
    stroke(0);
    strokeWeight(10);

    push();
    ambientLight(60, 60, 60);
    pointLight(35, 100, 189, 800, -400, 300);
    pointLight(230, 12, 189, -800, -400, 300);
    pointLight(50, 150, 95, 300, 100, -800);
    pointLight(250, 50, 25, 300, 100, 800);

    // Step 1
    for(var x=-400; x<=400; x+=50) {
        for(var z=-400; z<=400; z+=50) {
            push();
            translate(x,0,z);
            // Step 3
            var distance = dist(0,0,x,z);
            var value = slider.value();
            var length = map(sin(distance+value*4),-1,1,100,300);
            box(50,length+heightSlider.value(),50);
            pop();
        }
    }
    pop();
    
    push();
    normalMaterial();
    noStroke();
    confetti();
    pop();
}

function confetti() {
    for(var i=0; i<confLocs.length; i++) {
        push();
        translate(confLocs[i].x,confLocs[i].y,confLocs[i].z);
        rotateX(confTheta[i]);
        plane(15,15);

        confLocs[i].y+=1;
        confTheta[i]+=10;

        if(confLocs[i].y>0) {
            confLocs[i].y = -800;
        }

        pop();
    }
}