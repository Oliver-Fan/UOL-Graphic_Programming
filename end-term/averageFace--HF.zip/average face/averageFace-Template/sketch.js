/*
Comment on Work:
By following the instructions, I have implemented all basic requirements and developed futher 2 more ideas.

The images now can load successfully by using a for loop,
face images are appear on the left, grey canvas and average images are on the right. Images can set up correctly and they are looped over with 'loadPixels()' is called on them. Original face appears on the left, Conversion from 2D to 1D coordinate has taken place. 

For Further Development,
I used 'keyPressed()' function to achieve that any key pressed will change the fundemental presented image of left original image. This is because I have set a number type variable called 'imgIndex', and use random() to get a random value so that the image will change randomly when key pressed by updatePixels().

And I used 'mouseMoved()' function to check the movement of mouse, and use 'lerp()' in 'draw()' function to map the mouse location and recalculate the average face. If the value of mouseX getting bigger, the progress of average calculation will also getting further.  This can have the pixel values of the second image transition between the randomly selected image and the average image based on the mouseX value on mouse moved.


*/
var imgs = [];
var avgImg;
var numOfImages = 30;
var loadCounter = 0;
var imgIndex = 0; // determine the image on the left



//////////////////////////////////////////////////////////
function preload() { //preload all images once in order
    //STEP  1
    for (var i = 0; i < numOfImages; i++) {
        var filename = "assets/" + i + ".jpg";
        imgs.push(loadImage(filename, imageloadedSuccess));
    }
}
//////////////////////////////////////////////////////////
function setup() {
    //STEP 2----create for original face
    var leftImg = imgs[imgIndex];
    createCanvas(leftImg.width * 2, leftImg.height);
    pixelDensity(1);

    //STEP 3----create for average face
    createGraphics(leftImg.width, leftImg.height);
}
//////////////////////////////////////////////////////////
function draw() {
    background(125);

    //if the number of loaded img not equal to the numOfImages, show the "Not Ready" message
    if (loadCounter != numOfImages) {
        console.log("Not Ready");
        return
    }

    //STEP 4
    //load the pixels of all images in the array
    for (var i = 0; i < imgs.length; i++) {
        imgs[i].loadPixels();
    }
    // create a blank image to store all the average RGB value
    avgImg = createImage(imgs[0].width, imgs[0].height);
    avgImg.loadPixels();

    //STEP 5
    // each row
    for (var y = 0; y < avgImg.height; y++) {
        // each column
        for (var x = 0; x < avgImg.width; x++) {
            var pixelIndex = ((avgImg.width * y) + x) * 4;

            var r = imgs[imgIndex].pixels[pixelIndex + 0];
            var g = imgs[imgIndex].pixels[pixelIndex + 1];
            var b = imgs[imgIndex].pixels[pixelIndex + 2];

            imgs[imgIndex].pixels[pixelIndex + 0] = r;
            imgs[imgIndex].pixels[pixelIndex + 1] = g;
            imgs[imgIndex].pixels[pixelIndex + 2] = b;
            imgs[imgIndex].pixels[pixelIndex + 3] = 255;

            avgImg.pixels[pixelIndex + 0] = 255;
            avgImg.pixels[pixelIndex + 1] = 0;
            avgImg.pixels[pixelIndex + 2] = 0;
            avgImg.pixels[pixelIndex + 3] = 255;

            // compute the average RGB for each pixel from all the images
            var sumR = 0;
            var sumG = 0;
            var sumB = 0;

            // go to each image in images to get the rgb value for that pixelIndex
            for (var i = 0; i < imgs.length; i++) {
                var img = imgs[i];
                sumR += img.pixels[pixelIndex + 0];
                sumG += img.pixels[pixelIndex + 1];
                sumB += img.pixels[pixelIndex + 2];
            }

            //Further Dev: calculate the average face img with mouseX changes
            // get the lerp value
            var mouseMap = map(mouseX, 0, avgImg.width * 2, 0, 1);

            avgImg.pixels[pixelIndex + 0] = lerp(imgs[imgIndex].pixels[pixelIndex + 0], sumR / imgs.length, mouseMap);
            avgImg.pixels[pixelIndex + 1] = lerp(imgs[imgIndex].pixels[pixelIndex + 1], sumG / imgs.length, mouseMap);
            avgImg.pixels[pixelIndex + 2] = lerp(imgs[imgIndex].pixels[pixelIndex + 2], sumB / imgs.length, mouseMap);
        }
    }

    imgs[imgIndex].updatePixels(); // update first image
    image(imgs[imgIndex], 0, 0);

    avgImg.updatePixels();
    image(avgImg, 512, 0);

    noLoop();
}


// to check whether image has loaded successfully
function imageloadedSuccess() {
    loadCounter++;
    console.log(loadCounter);
    console.log("images loaded successfully");
}

//Further Dev: Press any key to change the image.
function keyPressed() {
    imgIndex = int(random(0, 30)); // randomize the imgIndex to determine image on the left
    loop();
}
//Further Dev : change the calculation of avrage face with the change of mouseX value
function mouseMoved() {
    loop();
}
