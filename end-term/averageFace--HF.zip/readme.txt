Comment on Work:

By following the instructions,
I have implemented all basic requirements and developed futher 2 more ideas.

The images now can load successfully by using a for loop,
face images are appear on the left, 
grey canvas and average images are on the right. 
Images can set up correctly and they are looped over 
with 'loadPixels()' is called on them. 
Original face appears on the left, 
Conversion from 2D to 1D coordinate has taken place. 

For Further Development,
I used 'keyPressed()' function to achieve that any key pressed will change 
the fundemental presented image of left original image. 
This is because I have set a number type variable called 'imgIndex', 
and use random() to get a random value so that the image will change randomly
when key pressed by updatePixels().

And I used 'mouseMoved()' function to check the movement of mouse, 
and use 'lerp()' in 'draw()' function to map the mouse location and 
recalculate the average face. If the value of mouseX getting bigger, 
the progress of average calculation will also getting further.  
This can have the pixel values of the second image transition between 
the randomly selected image and the average image based on the mouseX value 
on mouse moved.

Thank you.