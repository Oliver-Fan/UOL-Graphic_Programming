Comment on work:

I have implemented the basic working of webcam piano by
following the instructions,It almost looks the same like 
what shows at the top of the page.Webcam video image is on left side 
and the mimid drawing image is on right side with a white background.
A threshold slider at the left-top corner to control.
No extension has been applied. Thank you.

