class Note{
    static noteSize;
    constructor(notePos,noteState){
        this.notePos=notePos;//array
        this.noteState=noteState;//array
    }
}