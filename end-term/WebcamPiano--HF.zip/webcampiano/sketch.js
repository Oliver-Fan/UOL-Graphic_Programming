// ********************************
// BACKGROUND SUBTRACTION EXAMPLE *
// ********************************
/*
Comment on work:

I have implemented the basic working of webcam piano by
following the instructions,It almost looks the same like what shows at the top of the page. No extension has been applied

*/

var video;
//Step 1 
var prevImg; //rename by backImg
var diffImg;
var currImg;
var thresholdSlider;
var threshold;
var grid;

function setup() {
    createCanvas(640 * 2, 480);
    pixelDensity(1);
    video = createCapture(VIDEO);
    video.hide();

    //set for threshold slider
    thresholdSlider = createSlider(0, 255, 50);
    thresholdSlider.position(20, 20);
    grid = new Grid(640, 480);
}

function draw() {
    background(0);
    image(video, 0, 0);

    //Step 4
    threshold = thresholdSlider.value();

    //Step 5
    currImg = createImage(video.width, video.height);
    currImg.copy(video, 0, 0, video.width, video.height, 0, 0, video.width, video.height);
    currImg.resize(currImg.width / 4, currImg.height / 4);
    currImg.filter(BLUR, 3);

    diffImg = createImage(video.width, video.height);
    diffImg.resize(diffImg.width / 4, diffImg.height / 4);
    diffImg.loadPixels();

    if (typeof prevImg !== 'undefined') {
        prevImg.loadPixels();
        currImg.loadPixels();
        for (var x = 0; x < currImg.width; x += 1) {
            for (var y = 0; y < currImg.height; y += 1) {
                var index = (x + (y * currImg.width)) * 4;
                var curr_red = currImg.pixels[index + 0];
                var curr_green = currImg.pixels[index + 1];
                var curr_blue = currImg.pixels[index + 2];

                var prev_red = prevImg.pixels[index + 0];
                var prev_green = prevImg.pixels[index + 1];
                var prev_blue = prevImg.pixels[index + 2];

                var d = dist(curr_red, curr_green, curr_blue, prev_red, prev_green, prev_blue);

                if (d > threshold) {
                    diffImg.pixels[index + 0] = 0;
                    diffImg.pixels[index + 1] = 0;
                    diffImg.pixels[index + 2] = 0;
                    diffImg.pixels[index + 3] = 255;
                } else {
                    diffImg.pixels[index + 0] = 255;
                    diffImg.pixels[index + 1] = 255;
                    diffImg.pixels[index + 2] = 255;
                    diffImg.pixels[index + 3] = 255;
                }
            }
        }
    }
    diffImg.updatePixels();
    image(diffImg, 640, 0);

    noFill();
    stroke(255);
    text(threshold, 160, 35);
    copyCurrentToPrevImage();

    grid.run(diffImg);
}

function copyCurrentToPrevImage() {
    prevImg = createImage(currImg.width, currImg.height);
    prevImg.copy(currImg, 0, 0, currImg.width, currImg.height, 0, 0, currImg.width, currImg.height);
}

// faster method for calculating color similarity which does not calculate root.
// Only needed if dist() runs slow
function distSquared(x1, y1, z1, x2, y2, z2) {
    var d = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1) + (z2 - z1) * (z2 - z1);
    return d;
}
