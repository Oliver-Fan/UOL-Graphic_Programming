Comment on Work:
By following the instructions, I have implemented all 3 
basic filters: Sepia filter, Vignetting filter and 
RadialBlur filter. And developed one further more filter,
which is the 'GreyScale filter', with some logic to link all these filters.

With the logic I add in 'keyPressed()' function and matrix I predefined,
user can change different type of filters by pressing the different 
number key, once other unpointed key or mouse is pressed at blank space, 
It will comes back to the first filter in a vague mode.If you clicking 
on the face of the boy in the color image, the filter image 
will become clear, this part of code can be found 
in 'radialBlurFilter()' function. 

In detail,1 is for Sepia filter; 2 is for Vignetting; 
3 is for RadialBlur filter and 4 is for GreyScale filter.

The 'GreyScale' filter is to change the color style to all grey
so that the image looks more old fashion. 

Thank you.