/*
Comment on Work:
By following the instructions, I have implemented all 3 
basic filters: Sepia filter, Vignetting filter and 
RadialBlur filter. And developed one further more filter,
which is the 'GreyScale filter'. 

With the logic I add in 'keyPressed()' function and matrix I predefined, user can change different type of filters by pressing the different number key, once other unpointed key or mouse is pressed at blank space, It will comes back to the first filter in a vague mode.If you clicking on the face of the boy in the color image, the filter image will become clear, this part of code can be found in 'radialBlurFilter()' function. 

In detail,1 is for Sepia filter; 2 is for Vignetting; 3 is for RadialBlur filter and 4 is for GreyScale filter.
The 'GreyScale' filter is to change the color style to all grey so that the image looks more old fashion.
*/

var imgIn;
var matrix = [
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64],
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64],
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64],
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64],
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64],
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64],
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64],
    [1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64, 1 / 64]
];

/////////////////////////////////////////////////////////////////
function preload() {
    imgIn = loadImage("assets/image.jpg");
}
/////////////////////////////////////////////////////////////////
function setup() {
    createCanvas((imgIn.width * 2), imgIn.height + 240);
}
/////////////////////////////////////////////////////////////////
function draw() {
    background(255);
    image(imgIn, 0, 0);
    image(earlyBirdFilter(imgIn), imgIn.width, 0);

    //menu at the bottom to guide
    fill(0);
    textSize(20);
    text('Click the following number on your keyboard to change the filter:', 10, imgIn.height + 30);
    stroke(10);
    text('1. [Sepia]', 10, imgIn.height + 80);
    text('2. [Vignetting]', 130, imgIn.height + 80);
    text('3. [Radial Blur]', 270, imgIn.height + 80);
    text('4. [Grayscale]', 460, imgIn.height + 80);
    noStroke();
    text('Click any other key or click your mouse anywhere on the screen for the Early Bird filter.', 10, imgIn.height + 130);

    noLoop();
}
/////////////////////////////////////////////////////////////////
function mousePressed() {
    loop();
}
/////////////////////////////////////////////////////////////////

//Further Dev: Logic for changing filter style by press key on keyboard, 
function keyPressed() {
    if (keyCode == 49) // if press 1, show sepia filter
    {
        var resultImg = createImage(imgIn.width, imgIn.height);
        resultImg = sepiaFilter(resultImg);
        image(resultImg, imgIn.width, 0);
    } else if (keyCode == 50) // if press 2, show vignette filter
    {
        var resultImg = createImage(imgIn.width, imgIn.height);
        resultImg = noFilter(resultImg);
        resultImg = darkCorners(resultImg);
        image(resultImg, imgIn.width, 0);
    } else if (keyCode == 51) // if press 3, show border filter
    {
        var resultImg = createImage(imgIn.width, imgIn.height);
        resultImg = noFilter(resultImg);
        resultImg = borderFilter(resultImg);
        image(resultImg, imgIn.width, 0);
    } else if (keyCode == 52) // if press 4, show grayscale filter
    {
        var resultImg = createImage(imgIn.width, imgIn.height);
        resultImg = noFilter(resultImg);
        resultImg = grayscaleFilter(resultImg);
        image(resultImg, imgIn.width, 0);
    } else {
        loop();
    }
}
/////////////////////////////////////////////////////////////////
function earlyBirdFilter(img) {

    var resultImg = createImage(imgIn.width, imgIn.height);
    //STEP 1
    resultImg = sepiaFilter(resultImg);
    //Step 2
    resultImg = darkCorners(resultImg);
    //Step 3
    resultImg = radialBlurFilter(resultImg);
    //Step 4
    resultImg = borderFilter(resultImg);
    return resultImg;
}
/////////////////////////////////////////////////////////////////
function noFilter(resultImg) {
    imgIn.loadPixels();
    resultImg.loadPixels();
    for (var x = 0; x < imgIn.width; x++) {
        for (var y = 0; y < imgIn.height; y++) {
            var pixelIndex = ((imgIn.width * y) + x) * 4;
            var red = imgIn.pixels[pixelIndex + 0];
            var green = imgIn.pixels[pixelIndex + 1];
            var blue = imgIn.pixels[pixelIndex + 2];
            resultImg.pixels[pixelIndex + 0] = red;
            resultImg.pixels[pixelIndex + 1] = green;
            resultImg.pixels[pixelIndex + 2] = blue;
            resultImg.pixels[pixelIndex + 3] = 255;
        }
    }
    resultImg.updatePixels();
    return resultImg;
}
/////////////////////////////////////////////////////////////////
//----------------------Step 1
function sepiaFilter(resultImg) {
    imgIn.loadPixels();
    resultImg.loadPixels();

    for (var x = 0; x < imgIn.width; x++) {
        for (var y = 0; y < imgIn.height; y++) {
            var pixelIndex = ((imgIn.width * y) + x) * 4;
            var oldRed = imgIn.pixels[pixelIndex + 0];
            var oldGreen = imgIn.pixels[pixelIndex + 1];
            var oldBlue = imgIn.pixels[pixelIndex + 2];

            //STEP 1 -Copy the code over and modify it to turn the image into sepia
            newRed = (oldRed * .393) + (oldGreen * .769) + (oldBlue * .189);
            newGreen = (oldRed * .349) + (oldGreen * .686) + (oldBlue * .168);
            newBlue = (oldRed * .272) + (oldGreen * .534) + (oldBlue * .131);

            //copied code from Coursera instruction
            newRed = constrain(newRed, 0, 255);
            newGreen = constrain(newGreen, 0, 255);
            newBlue = constrain(newBlue, 0, 255);

            resultImg.pixels[pixelIndex + 0] = newRed;
            resultImg.pixels[pixelIndex + 1] = newGreen;
            resultImg.pixels[pixelIndex + 2] = newBlue;
            resultImg.pixels[pixelIndex + 3] = 255;
        }
    }
    resultImg.updatePixels();
    return resultImg;
}

/////////////////////////////////////////////////////////////////
// --------------------Step 2
function darkCorners(resultImg) {
    var midX = imgIn.width / 2;
    var midY = imgIn.height / 2;
    var maxDist = abs(dist(midX, midY, 0, 0));

    for (var x = 0; x < imgIn.width; x++) {
        for (var y = 0; y < imgIn.height; y++) {
            var d = abs(dist(x, y, midX, midY));
            if (d >= 300) {
                var pixelIndex = ((imgIn.width * y) + x) * 4;
                var oldRed = resultImg.pixels[pixelIndex + 0];
                var oldGreen = resultImg.pixels[pixelIndex + 1];
                var oldBlue = resultImg.pixels[pixelIndex + 2];
                var dynLum = 0;
                if (d <= 450) { // 300 to 450 scale by 1 to 0.4 depending on distance
                    dynLum = map(d, 300, 450, 1, 0.4);
                } else { // 450 to maxDist scale by a value between 0.4 and 0
                    dynLum = map(d, 450, maxDist, 0.4, 0);
                }
            }
            dynLum = constrain(dynLum, 0, 1);
            resultImg.pixels[pixelIndex + 0] = oldRed * dynLum;
            resultImg.pixels[pixelIndex + 1] = oldGreen * dynLum;
            resultImg.pixels[pixelIndex + 2] = oldBlue * dynLum;
        }
    }
    resultImg.updatePixels();
    return resultImg;
}
/////////////////////////////////////////////////////////////////
//-------------------Step 3
function convolution(x, y, matrix, matrixSize, img) {
    var totalRed = 0.0;
    var totalGreen = 0.0;
    var totalBlue = 0.0;
    var offset = floor(matrixSize / 2);

    // convolution matrix loop
    for (var i = 0; i < matrixSize; i++) {
        for (var j = 0; j < matrixSize; j++) {

            // Get pixel loc within convolution matrix
            var xloc = x + i - offset;
            var yloc = y + j - offset;
            var index = (xloc + img.width * yloc) * 4;

            // ensure we don't address a pixel that doesn't exist
            index = constrain(index, 0, img.pixels.length - 1);

            // multiply all values with the mask and sum up
            totalRed += img.pixels[index + 0] * matrix[i][j];
            totalGreen += img.pixels[index + 1] * matrix[i][j];
            totalBlue += img.pixels[index + 2] * matrix[i][j];
        }
    }
    // return the new color as an array
    return [totalRed, totalGreen, totalBlue];
}
/////////////////////////////////////////////////////////////////
//------------------Step 3
function radialBlurFilter(resultImg) {
    for (var x = 0; x < imgIn.width; x++) {
        for (var y = 0; y < imgIn.height; y++) {
            var pixelIndex = ((resultImg.width * y) + x) * 4;
            var oldRed = resultImg.pixels[pixelIndex + 0];
            var oldGreen = resultImg.pixels[pixelIndex + 1];
            var oldBlue = resultImg.pixels[pixelIndex + 2];

            // call convolution function
            var c = convolution(x, y, matrix, matrix.length, resultImg);

            //dynBlur is a value we generated using the distance from the mouse
            var mouseDist = abs(dist(x, y, mouseX, mouseY));
            var dynBlur = map(mouseDist, 100, 300, 0, 1);
            dynBlur = constrain(dynBlur, 0, 1);

            // c[0]=>red channel from convolution, 
            //c[1]=>green channel from convolution, 
            //c[2]=>blue channel from convolution

            //clicked on the face of the boy in the colour image
            resultImg.pixels[pixelIndex + 0] = c[0] * dynBlur + oldRed * (1 - dynBlur);
            resultImg.pixels[pixelIndex + 1] = c[1] * dynBlur + oldGreen * (1 - dynBlur);
            resultImg.pixels[pixelIndex + 2] = c[2] * dynBlur + oldBlue * (1 - dynBlur);
        }
    }
    resultImg.updatePixels();
    return resultImg;
}
/////////////////////////////////////////////////////////////////
//-----------------------Step 4
function borderFilter(resultImg) {
    // Draw the img onto the buffer
    var img = resultImg;

    //create a local buffer called buffer of the same size as the input image
    var buffer = createGraphics(img.width, img.height);
    buffer.image(resultImg, 0, 0);

    // Draw a big, fat, white rectangle with rounded corners around the image
    buffer.noFill();
    buffer.stroke(255);
    buffer.strokeWeight(20);
    buffer.rect(0, 0, img.width, img.height, 50);

    // Draw another rectangle without rounded corners, in order to get rid of the little triangles
    buffer.rect(0, 0, img.width, img.height);

    return buffer;
}
/////////////////////////////////////////////////////////////////

// ---------Further Dev: This function is developed filter, it will make the whole image change into grey color sytle,which makes the image more old fasion.
function grayscaleFilter(resultImg) {
    imgIn.loadPixels();
    resultImg.loadPixels();

    for (var x = 0; x < imgIn.width; x++) {
        for (var y = 0; y < imgIn.height; y++) {
            var pixelIndex = ((imgIn.width * y) + x) * 4;
            var red = imgIn.pixels[pixelIndex + 0];
            var green = imgIn.pixels[pixelIndex + 1];
            var blue = imgIn.pixels[pixelIndex + 2];

            var gray = red * 0.299 + green * 0.587 + blue * 0.114;

            resultImg.pixels[pixelIndex + 0] = gray;
            resultImg.pixels[pixelIndex + 1] = gray;
            resultImg.pixels[pixelIndex + 2] = gray;
            resultImg.pixels[pixelIndex + 3] = 255;
        }
    }
    resultImg.updatePixels();
    return resultImg;
}
