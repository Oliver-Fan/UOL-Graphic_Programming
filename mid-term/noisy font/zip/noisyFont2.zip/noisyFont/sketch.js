var points;
var font;
function preload() {
  font = loadFont('assets/Calistoga-Regular.ttf');
}

//////////////////////////////////////////////////////////////////////
function setup() {
  createCanvas(900, 400);
  background(0);

  points = font.textToPoints('c o d e', 50, 300, 300, {
    sampleFactor: .3,
    simplifyThreshold: 0
  });
  noStroke();
}

//////////////////////////////////////////////////////////////////////
function draw() {
	var a = map(mouseY, 0, height, 2, 8);
    fill(0,5,0,a);
    rect(0,0,width,height);

    // **** Your code here ****
	for (var i = 0; i < points.length; ++i) {
		var c = map(noise(frameCount), 0, 1, 128, 255);
		fill(c);
		var amt = map(mouseX, 0, width, 0, 80);
		var nX = noise((frameCount + 0) + points[i].x + points[i].y);
		var nY = noise((frameCount + 7) + points[i].x + points[i].y);
		var locX = map(nX, 0, 1,-amt, amt);
		var locY = map(nY, 0, 1,-amt, amt);
		var size = random(4, 7);
		ellipse(points[i].x + locX, points[i].y + locY, size, size);
	}
}
