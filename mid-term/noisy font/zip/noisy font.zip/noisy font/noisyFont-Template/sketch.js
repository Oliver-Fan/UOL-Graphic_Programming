var points;
var font;
function preload() {
  font = loadFont('assets/Calistoga-Regular.ttf');
}

//////////////////////////////////////////////////////////////////////
function setup() {
  createCanvas(900, 400);
  background(0);

  points = font.textToPoints('c o d e', 50, 300, 300, {
    sampleFactor: .3,
    simplifyThreshold: 0
  });
}

//////////////////////////////////////////////////////////////////////
function draw() {
  fill(0,5);
  rect(0,0,width,height);

  // **** Your code here ****
  background(0)

  for(var i = 0; i < points.length; i++){
    nFill = map(mouseX, 0, width, 0, 30)
    fill((255/random(0, 30)) * nFill, (0) * nFill, (255/random(0, 20)) * nFill)
    nX = map(mouseX, 0, width, 0, 30)
    ellipse(points[i].x + random(-nX, nX), points[i].y + random(-nX, nX), 10)
  }
}
