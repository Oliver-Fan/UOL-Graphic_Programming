/*
Tips: The origin point is at the left head corner, mouse move horizontally 
      will change the number of particles shking on the text
      mouse move vertically will change the path of particles. 
      The lower the mouse, the more confusing the particle's motion 
      trajectory becomes, and reaching the bottom of the boundary 
      makes the image unsightly.
*/


var points;
var font;

function preload() {
    font = loadFont('assets/Calistoga-Regular.ttf');
}

//////////////////////////////////////////////////////////////////////
function setup() {
    createCanvas(900, 400);
    background(0);

    points = font.textToPoints('c o d e', 50, 300, 300, {
        sampleFactor: .3,
        simplifyThreshold: 0
    });
}

//////////////////////////////////////////////////////////////////////
function draw() {
    //!!Bonus 4:Play with the trail the particles leave by modifying the fill of the rect in the draw function. Connect it with mouseY!
    var a = map(mouseY, 0, height, 0, 100);
    fill(10, 5, 0, a);
    rect(0, 0, width, height);

    // **** Your code here ****
    for (var i = 0; i < points.length; ++i) {
        var g = map(nX, 0, 1, 0, 255);
        var r = map(nY, 0, 1, 0, 255);
        //!!Bonus 2:Play with different colors.
        fill(r, g, 0);

        //--------------Step 4&5----------------------
        var nX = noise((frameCount + 0) + points[i].x + points[i].y);
        var nY = noise((frameCount + 5) + points[i].x + points[i].y);
        //--------------Step 3-------------------------
        //var amt = 20;
        //!!Bonus 1: play with amt.Set it to be dependent on mouseX and have it range from 0 to 80
        var amt = map(mouseX, 0, width, 0, 80);
        //Add that value returned from map() to the coordinate of each point.
        var movX = map(nX, 0, 1, -amt, amt);
        var movY = map(nY, 0, 1, -amt, amt);
        //!!Bonus 3: play with the size of the dots
        var size = random(1, 9);
        //--------------Step 2-------------------
        ellipse(points[i].x + movX, points[i].y + movY, size, size);
    }
}
